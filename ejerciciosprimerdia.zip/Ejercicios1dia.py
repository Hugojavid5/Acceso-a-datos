##Escribe un programa que imprima solo
##las palabras que tienen más de 10 letras
palabras = [
    "extraordinario", 
    "casa", 
    "impresionante", 
    "carro", 
    "carreterasonda", 
    "sencillo", 
    "espectaculares", 
    "computadoras", 
    "soledad", 
    "genialidad"
]
for palabra in palabras:
    if len(palabra) > 10:
        print(palabra)

##Escribe un programa que pase números decimales a binarios.
def decimal_a_binario(decimal):
    return bin(decimal)[2:]
decimal = int(input("Escribe un número decimal: "))
binario = decimal_a_binario(decimal)
print("El numero decimal",decimal ,"en binario es:" ,binario)

##Escribe un programa que añada espacios antes de la palabra, el número
##de espacios deberá ser el doble del tamaño de la palabra.
pal=str(input("escribe una palabra:"))
